<template>
  <v-app-bar app>
    <v-img :src="logo" alt="smashit.games Logo" height="40"></v-img>

    <v-spacer></v-spacer>

    <!-- Assuming "Hellfire Hands" should point to the homepage -->
    <v-btn text to="/">Hellfire Hands</v-btn>
    <!-- Assuming "About Us" should point to a '/about-us' route -->
    <v-btn text to="/about-us">About Us</v-btn>
    <v-btn text href="https://smash-it-games.notion.site/Job-Board-cb3cf317f59a4ba0bce1921b6e97c153">Jobs</v-btn>
    <v-btn text href="https://discord.gg/84zvK3y3Cs">Discord</v-btn>

    <!-- Theme Toggle Button -->
    <v-btn icon @click="toggleDarkMode">
      <v-icon>{{ themeIcon }}</v-icon>
    </v-btn>
  </v-app-bar>
</template>

<script>
import { useTheme } from 'vuetify'

export default {
  data() {
    return {
      logo: require('@/assets/smashitlogo-cropped.png')
    };
  },
  computed: {
    themeIcon() {
      return this.theme.global.current.value.dark ? 'mdi-moon-waxing-crescent' : 'mdi-white-balance-sunny';
    }
  },
  setup() {
    const theme = useTheme();

    function toggleDarkMode() {
      theme.global.name.value = theme.global.current.value.dark ? 'light' : 'dark';
    }

    return {
      theme,
      toggleDarkMode
    };
  }
}
</script>
